extension StringExtensions on String? {
  String orEmpty() => this ?? '';
}
