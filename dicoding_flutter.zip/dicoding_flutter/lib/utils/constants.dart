const String appName = 'Your Foods';

String assetsFonts(String name) => 'assets/fonts/$name';

String assetsRaw(String name) => 'assets/raw/$name';

String assetsIcons(String name) => 'assets/icons/$name';

const double defaultPadding = 16.0;
